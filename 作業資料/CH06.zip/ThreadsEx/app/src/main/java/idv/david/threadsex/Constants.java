package idv.david.threadsex;


public interface Constants {
    int MESSAGE_NORMAL = 0;
    int MESSAGE_ERROR = 1;

    int TASK_ADD = 0;
}
