package idv.david.threadsex;


import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class MyHandler extends Handler {
    private TextView textView;

    public MyHandler(TextView textView) {
        this.textView = textView;
    }

    @Override
    public void handleMessage(Message message) {
        switch (message.what) {
            case Constants.MESSAGE_NORMAL:
                switch (message.arg1) {
                    case Constants.TASK_ADD:
                        int sum = message.arg2;
                        String worker = message.obj.toString();
                        String text = worker + ", sum = " + String.valueOf(sum);
                        textView.setText(text);
                        break;
                }
                break;
            case Constants.MESSAGE_ERROR:
                textView.setText(message.obj.toString());
                break;

        }
    }
}
