package idv.david.threadsex;


import android.os.Handler;
import android.util.Log;

public class WorkThread extends Thread {
    private static final String TAG = "WorkThread";
    private static final String WORKER = "David";
    private int count;
    private Handler handler;

    public WorkThread(Handler handler, int count) {
        this.handler = handler;
        this.count = count;
    }

    @Override
    public void run() {
        for (int sum = 1; sum <= count; sum++) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Log.e(TAG, e.toString());
                handler.obtainMessage(
                        Constants.MESSAGE_ERROR,
                        WORKER + " got " + e.toString())
                        .sendToTarget();
            }
            handler.obtainMessage(
                    Constants.MESSAGE_NORMAL,
                    Constants.TASK_ADD,
                    sum,
                    WORKER)
                    .sendToTarget();
        }
    }
}
