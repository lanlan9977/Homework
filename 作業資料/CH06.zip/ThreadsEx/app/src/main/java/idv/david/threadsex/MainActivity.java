package idv.david.threadsex;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private TextView tvANR, tvUiThread, tvViewPost, tvHandler, tvAsyncTask;
    private ProgressBar progressBar;
    private Thread myThread, workThread;
    private MyHandler myHandler;
    private MyAsyncTask myAsyncTask;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvANR = findViewById(R.id.tvANR);
        tvUiThread = findViewById(R.id.tvUiThread);
        tvViewPost = findViewById(R.id.tvViewPost);
        tvHandler = findViewById(R.id.tvHandler);
        tvAsyncTask = findViewById(R.id.tvAsyncTask);

        progressBar = findViewById(R.id.progressBar);
    }

    /* Android will display the ANR dialog in the following conditions:
    1. No response to an input event within 5 seconds.
    2. A BroadcastReceiver hasn't finished executing within 10 seconds. */
    public void onANRClick(View view) {
        Log.d(TAG, "onANRClick");
        long count = 0;
        while (true) {
            count++;
            tvANR.setText(String.valueOf(count));
        }
    }

    // only UI thread (main thread) can touch views
    public void onUiThreadClick(View view) {
        Log.d(TAG, "onUiThreadClick");
        new Thread(new Runnable() {
            @Override
            public void run() {
                for (int count = 0; count < 10000; count++) {
                    tvUiThread.setText(String.valueOf(count));
                }
            }
        }).start();
    }

    /* post() causes the Runnable to be added to the message queue.
        The runnable will be run on the user interface thread. */
    public void onViewPostClick(View view) {
        Log.d(TAG, "onViewPostClick");
        if (myThread == null) {
            myThread = new Thread(new Runnable() {
                int count;

                @Override
                public void run() {
                    for (count = 0; count < 10000; count++) {
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            Log.e(TAG, e.toString());
                        }
                        tvViewPost.post(new Runnable() {
                            @Override
                            public void run() {
                                tvViewPost.setText(String.valueOf(count));
                            }
                        });
                    }
                }
            });
            myThread.start();
        }
    }

    public void onHandlerClick(View view) {
        Log.d(TAG, "onHandlerClick");
        if (myHandler == null) {
            myHandler = new MyHandler(tvHandler);
        }
        if (workThread == null) {
            workThread = new WorkThread(myHandler, 10000);
            workThread.start();
        }
    }

    public void onAsyncTaskClick(View view) {
        Log.d(TAG, "onAsyncTaskClick");
        if (myAsyncTask == null) {
            myAsyncTask = new MyAsyncTask();
            myAsyncTask.execute(100);
        }
    }

    private class MyAsyncTask extends AsyncTask<Integer, Integer, String> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Loading...");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(Integer... params) {
            int count = params[0];
            for (int i = 0; i <= count; i++) {
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Log.e(TAG, e.toString());
                }
                publishProgress(i);
            }
            return "Task completed!!";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            int progress = values[0];
            if (progressDialog.isShowing()) {
                progressDialog.cancel();
            }
            progressBar.setProgress(progress);
            tvAsyncTask.setText(String.valueOf(progress));
        }

        @Override
        protected void onPostExecute(String result) {
            progressBar.setVisibility(View.GONE);
            tvAsyncTask.setText(result);
        }
    }
}
